<?php
$conn = mysqli_connect("localhost", "root", "", "blood_donation");
$division = $_POST['division'];
$query = "SELECT * FROM districts WHERE 	division_id = $division";

$run_query = mysqli_query($conn,$query);

$output = '<option value="">Select District</option>';
// ;
 while($district = mysqli_fetch_assoc($run_query)){
    $output.='<option value="'.$district['id'].'">'.$district['name'].'</option>';
 }
// echo $output;
echo $output;
?>
