<?php
include('header/header.php');
include('header/navadmin.php');
include('header/connection.php');
?>

<!DOCTYPE html>
<html>

<head>
  <style>
    #customers {
      font-family: "Trebuchet MS", Arial, Helvetica, sans-serif;
      border-collapse: collapse;
      width: 90%;
      margin: 5px;
      text-align: center;
    }

    #customers td,
    #customers th {
      border: 1px solid #ddd;
      padding: 18px;

    }

    #customers tr:nth-child(even) {
      background-color: #f2f2f2;
    }

    #customers tr:hover {
      background-color: #ddd;
    }

    #customers th {
      padding-top: 12px;
      padding-bottom: 12px;
      text-align: center;
      background-color: #FF5733;
      color: white;
    }
  </style>
</head>

<body>
  <br>
  <h1 align="center">Patient List</h1>
  <br>
  <table id="customers" style="margin: 0px auto;">
    <tr>
      <th>No.</th>
      <th>ID</th>
      <th>Name</th>
      <th>Blood Group</th>
      <th>Gender</th>
      <th>Age</th>
      <th>Weight</th>
      <th>Phone Number</th>
      <th>Division</th>
      <th>District</th>
      <th>Address</th>

    </tr>
    <?php
    $q = $db->query("SELECT * FROM patient");
    $count=1;
    while ($p = $q->fetch(PDO::FETCH_OBJ)) {
      $district_q = $db->query("SELECT * FROM districts WHERE id='$p->district_id'");
      $district = $district_q->fetch(PDO::FETCH_OBJ);
      $division_q = $db->query("SELECT * FROM division WHERE id='$district->division_id'");
      $division = $division_q->fetch(PDO::FETCH_OBJ);
    ?>
      <tr>
        <td><?= $count; ?></td>
        <td><?= $p->id; ?></td>
        <td><?= $p->name; ?></td>
        <td><?= $p->bgroup; ?></td>
        <td><?= $p->gender; ?></td>
        <td><?= $p->age; ?></td>
        <td><?= $p->weight; ?></td>
        <td><?= $p->number; ?></td>
        <td><?= $district->name; ?></td>
        <td><?=  $district->name; ?></td>
        <td><?= $p->address; ?></td>
      </tr>
    <?php
    $count++;
    }
    ?>


  </table>

</body>

</html>