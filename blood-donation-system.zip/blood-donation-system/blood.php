<?php
session_start();
include('header/header.php');
include('header/connection.php');
if (isset($_SESSION['loggedin']) == true) {
	include('header/navadmin.php');
} else {
	include('header/navuser.php');
}
?>

<!DOCTYPE html>

<head>
	<title>Donor List | Welcome</title>

	<style>
		#customers {
			font-family: "Trebuchet MS", Arial, Helvetica, sans-serif;
			border-collapse: collapse;
			width: 90%;
			margin: 5px;
			text-align: center;
		}

		#customers td,
		#customers th {
			border: 1px solid #ddd;
			padding: 18px;
		}

		#customers tr:nth-child(even) {
			background-color: #f2f2f2;
		}

		#customers tr:hover {
			background-color: #ddd;
		}

		#customers th {
			padding-top: 12px;
			padding-bottom: 12px;
			text-align: center;
			background-color: #FF5733;
			color: white;
		}
	</style>
</head>
<br>
<div class="blood">
	<label>Search The Donors</label>
	<br><br>
	<label>Blood Group: </label>
	<form class="" action="" method="post">

		<select name="bgroup">
			<option>Select</option>
			<option>A+</option>
			<option>A-</option>
			<option>B+</option>
			<option>B-</option>
			<option>AB+</option>
			<option>AB-</option>
			<option>O+</option>
			<option>O-</option>

		</select>
		<br>

		<select name="division" id="division">
			<option disabled selected>Select Division </option>
			<option value="1">Chattogram</option>
			<option value="2">Rajshahi</option>
			<option value="3">Khulna</option>
			<option value="4">Barisal</option>
			<option value="5">Sylhet</option>
			<option value="6">Dhaka</option>
			<option value="7">Rangpur</option>
			<option value="8">Mymensingh</option>
		</select><br>
		<select name="district" id="district">
			<option disabled selected>Select District </option>
		</select>
		<br>
		<button type="submit" name="sub">Submit</button>

	</form>
</div>
<br></br>

<?php
if (isset($_POST['sub'])) {
	$bgroup = @$_POST['bgroup'];
	$district = $_POST['district'];
	// echo $district;

?>
	<h1 align="center">Donor List</h1>
	<br>
	<table id="customers" style="margin: 0px auto;">

		<tr>
			<th>ID</th>
			<th>Name</th>
			<th>Blood Group</th>
			<th>Gender</th>
			<th>Age</th>
			<th>Weight</th>
			<th>Last Donated</th>
			<th>Phone Number</th>
			<th>Division</th>
			<th>District</th>

		</tr>
		<?php
		$q = $db->query("SELECT * FROM donor WHERE bgroup='$bgroup' AND district_id='$district'");
		$district_q =$db->query("SELECT * FROM districts WHERE id='$district'");
		$district = $district_q->fetch(PDO::FETCH_OBJ);
		$division_q =$db->query("SELECT * FROM division WHERE id='$district->division_id'");
		$division = $division_q->fetch(PDO::FETCH_OBJ);
		// echo $division->name;
		$count = 0;
		while ($p = $q->fetch(PDO::FETCH_OBJ)) {
		?>
			<tr>
				<?php
				$current = date("Y/m/d");
				$month = ((strtotime($current) - strtotime($p->date	)) / 60 / 60 / 24) / 30;

				if ($month >= 3.0) {
				?>
					<td><?= $p->id; ?></td>
					<td><?= $p->name; ?></td>
					<td><?= $p->bgroup; ?></td>
					<td><?= $p->gender; ?></td>
					<td><?= $p->age; ?></td>
					<td><?= $p->weight; ?></td>
					<td><?= $p->date; ?></td>
					<td><?= $p->number; ?></td>
					<td><?= $division->name; ?></td>
					<td><?=  $district->name; ?></td>

				<?php

				}

				?>
			</tr>
		<?php
		}
		?>
	</table>
<?php

}

?>
<script type="text/javascript">
	$('#division').on('change', function() {
		console.log(this.value);
		$.ajax({
			type: 'POST',
			url: 'ajax.php',
			data: {
				'division': this.value
			},
			success: function(data) {
				// console.log(data);
				$('#district').html(data);
			}
		})
	});
</script>
</body>

</html>